package question2;

public abstract class BloodPressureStrategy {

	public abstract void printReport();

}
