package question2;

public class BloodPressureLow extends BloodPressureStrategy {

	@Override
	public void printReport() {
		// TODO Auto-generated method stub
		System.out.println("Low BP:" + "\n\tEat less salt." + "\n\tDrink more water."
				+ "\n\tWear compression stockings." + "\n\tTake medication.");
	}

}
