package question2;

public class BloodPressureHigh extends BloodPressureStrategy{

	@Override
	public void printReport() {
		// TODO Auto-generated method stub
		System.out.println("Pre-High BP:" + 
						"\n\tLose weight if overweight." +
						"\n\tExercise regularly." +
						"\n\tEat plenty of fruits, vegetables, whole grains, fish, and low-fat dairy." +
						"\n\tEat less salt and dietary sodium." +
						"\n\tEat a plant based diet." +
						"\n\tDrink only in moderation.");
	}

}
