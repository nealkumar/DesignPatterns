package question2;

public class BloodPressureNormal extends BloodPressureStrategy{

	@Override
	public void printReport() {
		// TODO Auto-generated method stub
		System.out.println("Normal BP:" + 
				"\n\tContinue to enjoy a healthy lifestyle.");
	}

}
