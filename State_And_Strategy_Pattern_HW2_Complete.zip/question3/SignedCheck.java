package question3;

public class SignedCheck extends Check {

	public SignedCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		System.out.println("Check has already been written and signed");
	}

	@Override
	public void sign() {
		System.out.println("Check has already been signed");
	}

	@Override
	public void endorse() {
		System.out.println("Check has now been endorsed");
		Check endorsedCheck = new EndorsedCheck(checkTransaction);
		endorsedCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(endorsedCheck);
	}

	@Override
	public void cash() {
		System.out.println("A check must be endorsed before it can be cashed");
	}

	@Override
	public void stopPayment() {
		System.out.println("Payment of this check has been stopped");
		Check stoppedPaymentCheck = new StoppedPaymentCheck(checkTransaction);
		stoppedPaymentCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(stoppedPaymentCheck);
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub
		Check voidedCheck = new VoidedCheck(checkTransaction);
		voidedCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(voidedCheck); // Talking back to the context
		System.out.println("Check voided.");
	}
}