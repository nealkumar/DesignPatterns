package question3;

public class CashedCheck extends Check {

	public CashedCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		System.out.println("Check has already been cashed, cannot change info");
	}

	@Override
	public void sign() {
		System.out.println("Check has already been cashed");
	}

	@Override
	public void endorse() {
		System.out.println("Check has already been endorsed and cashed");
	}

	@Override
	public void cash() {
		System.out.println("Check has already been cashed, cannot use again");
	}

	@Override
	public void stopPayment() {
		System.out.println("This check has already been cashed, too late to stop payment");
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub
		System.out.println("This check has already been cashed. Cannot void.");
	}
}
