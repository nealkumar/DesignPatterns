package question3;

public class ReturnedUncashedCheck extends Check {

	public ReturnedUncashedCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		System.out.println("This is no longer a valid check");
	}

	@Override
	public void sign() {
		System.out.println("This is no longer a valid check");
	}

	@Override
	public void endorse() {
		System.out.println("This is no longer a valid check");
	}

	@Override
	public void cash() {
		System.out.println("Cannot cash an unsigned check");
	}

	@Override
	public void stopPayment() {
		System.out.println("This is no longer a valid check");
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub
		System.out.println("Check already invalid.");
	}
}
