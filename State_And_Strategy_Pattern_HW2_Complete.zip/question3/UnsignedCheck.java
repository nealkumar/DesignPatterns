package question3;

public class UnsignedCheck extends Check {

	public UnsignedCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		System.out.println("Check information has already been entered");
	}

	@Override
	public void sign() {
		Check signedCheck = new SignedCheck(checkTransaction);
		signedCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(signedCheck);
	}

	@Override
	public void endorse() {
		System.out.println("It is unwise to endorse and unsigned check");
	}

	@Override
	public void cash() {
		System.out.println("Cannot cash an unsigned check");
	}

	@Override
	public void stopPayment() {
		System.out.println("Payment of this check has been stopped");
		Check stoppedPaymentCheck = new StoppedPaymentCheck(checkTransaction);
		stoppedPaymentCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(stoppedPaymentCheck);
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub
		Check voidedCheck = new VoidedCheck(checkTransaction);
		voidedCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(voidedCheck); // Talking back to the context
		System.out.println("Check voided.");
	}
}
