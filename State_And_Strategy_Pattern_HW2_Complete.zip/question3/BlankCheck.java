package question3;

public class BlankCheck extends Check {

	public BlankCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		checkInfo = new CheckInfo(payee, date, amount);
		System.out.println("Check has been written");
		Check unsignedCheck = new UnsignedCheck(checkTransaction);
		unsignedCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(unsignedCheck);
	}

	@Override
	public void sign() {
		System.out.println("It's quite foolish to sign a blank check");
	}

	@Override
	public void endorse() {
		System.out.println("It is unwise to endorse a blank check");
	}

	@Override
	public void cash() {
		System.out.println("Cannot cash a blank check");
	}

	@Override
	public void stopPayment() {
		System.out.println("Cannot stop payment on a blank check");
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub
		Check voidedCheck = new VoidedCheck(checkTransaction);
		voidedCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(voidedCheck); // Talking back to the context
		System.out.println("Check voided.");
	}
}