package question3;

public class InsufficientFundsCheck extends Check {

	public InsufficientFundsCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		System.out.println("Check has already been denied, cannot change info");
	}

	@Override
	public void sign() {
		System.out.println("Check has already been signed and denied");
	}

	@Override
	public void endorse() {
		System.out.println("Check has already been endorsed and payment denied");
	}

	@Override
	public void cash() {
		double balance = (checkTransaction.getAccount()).getBalance();
		if (balance >= checkInfo.getAmount() + RETURNFEE) {
			Check cashedCheck = new CashedCheck(checkTransaction);
			cashedCheck.setCheckInfo(checkInfo);
			checkTransaction.updateTransaction(cashedCheck);
			(checkTransaction.getAccount()).withdrawel(checkInfo.getAmount() + RETURNFEE);

		} else {
			System.out.println("There are STILL insufficient funds to cash this check");
			Check voidCheck = new ReturnedUncashedCheck(checkTransaction);
			voidCheck.setCheckInfo(checkInfo);
			checkTransaction.updateTransaction(voidCheck);
		}
	}

	@Override
	public void stopPayment() {
		System.out.println("This check was denied due to insufficient funds");
		System.out.println("Payment has now been stopped");
		Check stoppedPaymentCheck = new StoppedPaymentCheck(checkTransaction);
		stoppedPaymentCheck.setCheckInfo(checkInfo);
		checkTransaction.updateTransaction(stoppedPaymentCheck);
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub
		System.out.println("Check has already been denied. Cannot void.");
	}
}