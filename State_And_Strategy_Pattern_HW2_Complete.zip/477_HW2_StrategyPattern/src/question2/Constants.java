package question2;

public class Constants {

	public static final int LOW_MIN = 2800;
	public static final int LOW_MAX = 5399;
	public static final int NORMAL_MIN = 5400;
	public static final int NORMAL_MAX = 9599;
	public static final int HIGH_MIN = 9600;
	public static final int HIGH_MAX = 12599;
	public static final int VERY_HIGH_MIN = 12600;
	public static final int VERY_HIGH_MAX = 19000;

}
