package question2;

public class BloodPressureVeryHigh extends BloodPressureStrategy{

	@Override
	public void printReport() {
		// TODO Auto-generated method stub
		System.out.println("High BP:" + 
				"\n\tEat less salt." +
				"\n\tEat more fruits and vegetables." +
				"\n\tKeep to a healthy weight." +
				"\n\tDrink less alcohol." +
				"\n\tGet more active." +
				"\n\tTake medication.");
	}

}
