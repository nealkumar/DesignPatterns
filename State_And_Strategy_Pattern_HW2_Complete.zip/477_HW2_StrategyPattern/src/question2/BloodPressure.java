package question2;

import java.util.Hashtable;
import java.util.Scanner;

public class BloodPressure {

	private int lowMin = Constants.LOW_MIN;
	private int lowMax = Constants.LOW_MIN;
	private int normalMin = Constants.NORMAL_MIN;
	private int normalMax = Constants.NORMAL_MAX;
	private int highMin = Constants.HIGH_MIN;
	private int highMax = Constants.HIGH_MAX;
	private int veryHighMin = Constants.VERY_HIGH_MIN;
	private int veryHighMax = Constants.VERY_HIGH_MAX;

	// Variable to store the active strategy
	BloodPressureStrategy printReport;

	// Objects of each sub-class to printReport() depending on client input
	private BloodPressureStrategy low = new BloodPressureLow();
	private BloodPressureStrategy normal = new BloodPressureNormal();
	private BloodPressureStrategy high = new BloodPressureHigh();
	private BloodPressureStrategy veryHigh = new BloodPressureVeryHigh();

	// Hashtable of Strategies
	Hashtable<Integer, BloodPressureStrategy> hashtable = new Hashtable<Integer, BloodPressureStrategy>();

	private Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		new BloodPressure().execute();
	}

	public void execute() {
		int diastolic = getBloodPressure("d");
		int systolic = getBloodPressure("s");

		// Use Hashtable instead of conditionals to implement correct strategy
		this.hashtable = populateHashtable(hashtable);
		int value = calculateValue(diastolic, systolic);
		printReport = searchHashtable(value, hashtable);

		printReport.printReport();
	}

	public BloodPressureStrategy searchHashtable(int key, Hashtable<Integer, BloodPressureStrategy> hashtable) {
		BloodPressureStrategy strategy = hashtable.get(key);
		return strategy;
	}

	/**
	 * Will refactor later to include a method (that uses min, max in a single loop)
	 * to avoid repeating the for-loop
	 * 
	 * @param hashtable
	 * @return
	 */
	public Hashtable<Integer, BloodPressureStrategy> populateHashtable(
			Hashtable<Integer, BloodPressureStrategy> hashtable) {

		initPopulation(hashtable, lowMin, lowMax, low);
		initPopulation(hashtable, normalMin, normalMax, normal);
		initPopulation(hashtable, highMin, highMax, high);
		initPopulation(hashtable, veryHighMin, veryHighMax, veryHigh);

		return hashtable;
	}

	public Hashtable<Integer, BloodPressureStrategy> initPopulation(Hashtable<Integer, BloodPressureStrategy> hashtable,
			int start, int end, BloodPressureStrategy bps) {

		for (int key = start; key < end; key++) {
			hashtable.put(key, bps);
		}

		return hashtable;
	}

	public int calculateValue(int diastolic, int systolic) {
		int multiplied = diastolic * systolic;
		System.out.println(multiplied);
		return multiplied;
	}

	public int getBloodPressure(String type) {
		if (type.equals("d")) {
			System.out.println("What's your diastolic BP?");
			int result = input.nextInt();
			return result;
		} else {
			System.out.println("What's your systolic BP?");
			int result = input.nextInt();
			return result;
		}
	}
}
