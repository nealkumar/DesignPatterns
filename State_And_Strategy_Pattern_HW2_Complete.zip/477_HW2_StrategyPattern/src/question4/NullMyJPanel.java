package question4;

/*  "Null" version of a MyJPanel, does everything a MyJPanel can do, and less!
    It overrides all methods, repalcing them with empty versions that simply
    don't do anything when invoked.
*/

public class NullMyJPanel extends MyJPanel {

	private static NullMyJPanel nullPanel;

	// The constructor for this class is private?? How does that work??-
	private NullMyJPanel() {
	}

	public static NullMyJPanel getNullPanel() {

		if (nullPanel == null) {
			nullPanel = new NullMyJPanel();
		}
		return nullPanel;
	}

	@Override
	public void setCenter() {
	}

	@Override
	public void setNorthCross() {
	}

	@Override
	public void setSouthCross() {
	}

	@Override
	public void setEastCross() {
	}

	@Override
	public void setWestCross() {
	}

	@Override
	public void resetCenter() {
	}

	@Override
	public void resetNorthCross() {
	}

	@Override
	public void resetSouthCross() {
	}

	@Override
	public void resetEastCross() {
	}

	@Override
	public void resetWestCross() {
	}
}
