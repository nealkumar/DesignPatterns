package question4;

import java.awt.Color;

public class WhiteRetainer extends ColorRetainer {

	ColorRetainer greenRetainer;

	public WhiteRetainer(ColorRetainer greenRetainer) {
		this.greenRetainer = greenRetainer;
	}

	@Override
	public Color returnColor() {
		// TODO Auto-generated method stub
		return Color.white;
	}

	@Override
	/**
	 * This is the method that changes JPanel color to green from white
	 */
	public ColorRetainer switchColors() {
		// TODO Auto-generated method stub
		return new GreenRetainer(greenRetainer);
	}

}
