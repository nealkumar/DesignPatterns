package question4;

import java.awt.Color;

/* Uses the approach of every panel having a link to it's immediate,
   4-connected neighborhood.  Propagates messages (turn red, or turn back)
   in all 4 directions until the edge null-object is encountered.  Uses two
   sets of methods to propagate the two different messages.
*/

import javax.swing.JPanel;

public class MyJPanel extends JPanel {

	boolean changed = false;
	ColorRetainer myColor;
	MyJPanel north, south, east, west;

	public MyJPanel() {
	}

	public MyJPanel(ColorRetainer myColor) {
		super();
		this.myColor = myColor;
		setBackground(myColor.returnColor());
		this.addMouseListener(new MyMouseListener(this));
	}

	public void setNorthNeighbor(MyJPanel north) {
		this.north = north;
	}

	public void setSouthNeighbor(MyJPanel south) {
		this.south = south;
	}

	public void setWestNeighbor(MyJPanel west) {
		this.west = west;
	}

	public void setEastNeighbor(MyJPanel east) {
		this.east = east;
	}

	public void setCenter() {
		this.setBackground(Color.yellow);
		north.setNorthCross();
		south.setSouthCross();
		east.setEastCross();
		west.setWestCross();
	}

	public void resetCenter() {
		this.setBackground(myColor.returnColor());
		north.resetNorthCross();
		south.resetSouthCross();
		east.resetEastCross();
		west.resetWestCross();
	}

	public void setNorthCross() {
		this.setBackground(Color.red);
		north.setNorthCross();
	}

	public void resetNorthCross() {
		this.setBackground(myColor.returnColor());
		north.resetNorthCross();
	}

	public void setSouthCross() {
		this.setBackground(Color.red);
		south.setSouthCross();
	}

	public void resetSouthCross() {
		this.setBackground(myColor.returnColor());
		south.resetSouthCross();
	}

	public void setEastCross() {
		this.setBackground(Color.red);
		east.setEastCross();
	}

	public void resetEastCross() {
		this.setBackground(myColor.returnColor());
		east.resetEastCross();
	}

	public void setWestCross() {
		this.setBackground(Color.red);
		west.setWestCross();
	}

	public void resetWestCross() {
		this.setBackground(myColor.returnColor());
		west.resetWestCross();
	}

	public void setChanged() {
		myColor = myColor.switchColors();
	}

}
