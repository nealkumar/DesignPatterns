package question4;

/* "Blue" subclass of ColorRetainer, knows it is blue and knows when it is
   told to change that it should become green
*/
import java.awt.Color;

public class BlueRetainer extends ColorRetainer {

	ColorRetainer whiteRetainer;

	public BlueRetainer() {
		whiteRetainer = new WhiteRetainer(this);
	}

	@Override
	public Color returnColor() {
		return Color.blue;
	}

	@Override
	public ColorRetainer switchColors() {
		return whiteRetainer;
	}
}
