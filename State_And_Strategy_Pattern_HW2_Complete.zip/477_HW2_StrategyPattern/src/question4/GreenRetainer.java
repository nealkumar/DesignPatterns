package question4;

/* "Green" subclass of ColorRetainer, knows it is green and knows when it is
   told to change that it should become blue
*/
import java.awt.Color;

class GreenRetainer extends ColorRetainer {

	ColorRetainer blueRetainer;

	public GreenRetainer(ColorRetainer blueRetainer) {
		this.blueRetainer = blueRetainer;
	}

	@Override
	public Color returnColor() {
		return Color.green;
	}

	@Override
	public ColorRetainer switchColors() {
		return blueRetainer;
	}
}
