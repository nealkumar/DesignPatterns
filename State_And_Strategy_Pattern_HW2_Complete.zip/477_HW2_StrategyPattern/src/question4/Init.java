package question4;

/* This implementation of the CrossHairs program makes use of Two
   Design Patterns, Adapter and State. 

   The State pattern is used to transparently switch between the Blue
   and Green status of the panels.  At no point in this program
   will you find a conditional that checks whether a panel is
   green or blue and performs a different action.
   
   The Adapter is used for the mouse listener class.

*/
import java.awt.GridLayout;

import javax.swing.JFrame;

public class Init {

	public static Init init;

	private MyJPanel grid[][];

	public Init() {
	}

	public static void main(String args[]) {
		init = new Init();

		init.go();
	}

	public void go() {
		JFrame display = new JFrame("CrossHairs");
		ColorRetainer blueRetainer;
		display.setSize(500, 500);
		grid = new MyJPanel[10][10];

		// Only a Blue retainer is explicitly created here, the green one
		// is made in the constructor for the blue one, they can then generate
		// links between each other and "ping-pong" back and forth between the two
		blueRetainer = new BlueRetainer();
		display.getContentPane().setLayout(new GridLayout(10, 10));
		display.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		for (int row = 0; row < 10; row++) {
			for (int col = 0; col < 10; col++) {
				// each MyJPanel is given a reference to the single "Blue" color
				grid[row][col] = new MyJPanel(blueRetainer);
				display.getContentPane().add(grid[row][col]);
			}
		}

		// This could be done less prodcedurally, but this is the
		// obvious, quick way of doing it
		for (int row = 0; row < 10; row++) {
			for (int col = 0; col < 10; col++) {
				if (row > 0) {
					grid[row][col].setNorthNeighbor(grid[row - 1][col]);
				} else {
					grid[row][col].setNorthNeighbor(NullMyJPanel.getNullPanel());
				}
				if (row < 9) {
					grid[row][col].setSouthNeighbor(grid[row + 1][col]);
				} else {
					grid[row][col].setSouthNeighbor(NullMyJPanel.getNullPanel());
				}
				if (col > 0) {
					grid[row][col].setWestNeighbor(grid[row][col - 1]);
				} else {
					grid[row][col].setWestNeighbor(NullMyJPanel.getNullPanel());
				}
				if (col < 9) {
					grid[row][col].setEastNeighbor(grid[row][col + 1]);
				} else {
					grid[row][col].setEastNeighbor(NullMyJPanel.getNullPanel());
				}
			}
		}
		display.setVisible(true);
	}
}
