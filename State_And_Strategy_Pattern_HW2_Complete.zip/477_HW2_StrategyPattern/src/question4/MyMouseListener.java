package question4;

import java.awt.event.MouseEvent;

/* Nice, simple, concise implementation of the MouseListener, each method calls
   a single, well-named method -- this is easy to follow.  Note, this also uses
   the MouseAdapter to save some typing
*/
import javax.swing.event.MouseInputAdapter;

public class MyMouseListener extends MouseInputAdapter {

	private MyJPanel myJPanel;

	public MyMouseListener(MyJPanel myJPanel) {
		this.myJPanel = myJPanel;
	}

	@Override
	public void mouseEntered(MouseEvent me) {
		myJPanel.setCenter();
	}

	@Override
	public void mouseExited(MouseEvent me) {
		myJPanel.resetCenter();
	}

	@Override
	public void mouseClicked(MouseEvent me) {
		myJPanel.setChanged();
	}
}
