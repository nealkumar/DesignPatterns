package question4;
/* Abstract class that requires two methods: returnColor and switchColors.
   Color-specific sub-classes of this class need to implement these methods.
   The first specifies the color stored, the second changes the color stored
*/

import java.awt.Color;

public abstract class ColorRetainer {

	public ColorRetainer() {
	}

	public abstract Color returnColor();

	public abstract ColorRetainer switchColors();
}
