package question3;

public class VoidedCheck extends Check {

	public VoidedCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		// TODO Auto-generated method stub
		System.out.println("Check voided. Cannot enter info.");
	}

	@Override
	public void sign() {
		// TODO Auto-generated method stub
		System.out.println("Check voided. Cannot sign.");
	}

	@Override
	public void endorse() {
		// TODO Auto-generated method stub
		System.out.println("Check voided. Cannot endorse.");
	}

	@Override
	public void cash() {
		// TODO Auto-generated method stub
		System.out.println("Check voided. Cannot cash.");
	}

	@Override
	public void stopPayment() {
		// TODO Auto-generated method stub
		System.out.println("Check voided. Cannot stop payment.");
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub

	}

}
