package question3;

public class StoppedPaymentCheck extends Check {

	public StoppedPaymentCheck(CheckTransaction checkTransaction) {
		super(checkTransaction);
	}

	@Override
	public void fillIn(String payee, Date date, double amount) {
		System.out.println("Payment on this check has been stopped, it cannot be changed");
	}

	@Override
	public void sign() {
		System.out.println("Payment on this check has been stopped");
	}

	@Override
	public void endorse() {
		System.out.println("Payment on this check has been stopped, it cannot be endorsed");
	}

	@Override
	public void cash() {
		System.out.println("Payment on this check has been stopped, in cannot be cashed");
	}

	@Override
	public void stopPayment() {
		System.out.println("Payment of this check has already been stopped");
	}

	@Override
	public void voidCheck() {
		// TODO Auto-generated method stub
		System.out.println("Payment of this check has already been stopped. Cannot void.");
	}
}
